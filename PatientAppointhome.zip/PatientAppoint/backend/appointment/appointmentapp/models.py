from django.db import models


class User(models.Model):
    fullname = models.CharField(max_length=100)
    date_of_birth = models.DateField()
    email = models.EmailField()
    phone = models.CharField(max_length=10)
    password = models.CharField(max_length=100)
    address = models.TextField()
    
class Doctor(models.Model):
    image = models.ImageField(upload_to='images/')
    name = models.CharField(max_length=100)
    specialization = models.CharField(max_length=50)
    location = models.TextField()
    availability = models.JSONField()
    email = models.EmailField()
    password = models.CharField(max_length=100) 
    
class Appointment(models.Model):
    patient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='appointments')
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    date = models.DateField()
    time = models.TimeField()
    notes = models.TextField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=[('Pending', 'Pending'), ('Confirmed', 'Confirmed')])