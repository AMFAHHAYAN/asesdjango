from rest_framework import generics, status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework_simplejwt.tokens import RefreshToken
from django.utils import timezone
from django.conf import settings

from .models import User, Doctor, Appointment
from .serializers import *
from .permissions import IsOwner

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = Registerserializer
    permission_classes = [AllowAny]

    def perform_create(self, serializer):
        # Additional validation or pre-create logic can be added here
        user = serializer.save()
        
        # Optional: Additional post-registration actions
        return user

class LoginView(generics.GenericAPIView):
    serializer_class = LoginSerializer
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        
        if serializer.is_valid():
            email = serializer.validated_data.get('email')
            user = User.objects.get(email=email)
            
            # Generate JWT tokens with custom claims
            refresh = RefreshToken.for_user(user)
            refresh['email'] = user.email
            
            # Optional: Track login attempts
            user.last_login = timezone.now()
            user.save()
            
            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
                'user_id': user.id,
                'email': user.email
            }, status=status.HTTP_200_OK)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class LogoutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            # Get the refresh token from the request
            refresh_token = request.data.get('refresh_token')
            
            # Blacklist the refresh token
            token = RefreshToken(refresh_token)
            token.blacklist()

            return Response({
                'detail': 'Successfully logged out.'
            }, status=status.HTTP_205_RESET_CONTENT)
        except Exception as e:
            return Response({
                'detail': 'Logout failed.',
                'error': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)

class UserRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = Registerserializer
    permission_classes = [IsAuthenticated, IsOwner]

    def get_queryset(self):
        # Ensure user can only access their own record
        return User.objects.filter(id=self.request.user.id)

    def perform_update(self, serializer):
        # Additional validation or logging can be added
        serializer.save()

    def perform_destroy(self, instance):
        # Soft delete or additional logging
        instance.is_active = False
        instance.save()

class DoctorListCreateView(generics.ListCreateAPIView):
    queryset = Doctor.objects.all()
    serializer_class = Doctorserializer
    permission_classes = [IsAuthenticated]

class DoctorRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Doctor.objects.all()
    serializer_class = Doctorserializer
    permission_classes = [IsAuthenticated]

class AppointmentListCreateView(generics.ListCreateAPIView):
    serializer_class = Appointemntserializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        # Restrict appointments based on user type
        user = self.request.user
        if hasattr(user, 'is_doctor') and user.is_doctor:
            return Appointment.objects.filter(doctor=user)
        return Appointment.objects.filter(patient=user)

class AppointmentRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = Appointemntserializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        # Restrict appointment access based on user type
        user = self.request.user
        if hasattr(user, 'is_doctor') and user.is_doctor:
            return Appointment.objects.filter(doctor=user)
        return Appointment.objects.filter(patient=user)