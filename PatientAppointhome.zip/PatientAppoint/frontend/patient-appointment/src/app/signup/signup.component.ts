import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { passwordStrengthValidator } from '../validators/password-strength-validator';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signupForm: FormGroup;
  submitted = false;
  errorMessage = '';

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.signupForm = this.formBuilder.group({
      fullName: ['', [Validators.required, Validators.minLength(2)]],
      dateOfBirth: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      phoneNumber: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      password: ['', [
        Validators.required, 
        Validators.minLength(8),
        passwordStrengthValidator()
      ]],
      address: [''],
      termsAccepted: [false, Validators.requiredTrue]
    });
  }

  onSubmit() {
    this.submitted = true;

    if (this.signupForm.invalid) {
      return;
    }

    // this.authService.signup(this.signupForm.value).subscribe({
    //   next: (response) => {
    //     // Handle successful signup (redirect, show success message)
    //     console.log('Signup successful', response);
    //   },
    //   error: (error) => {
    //     this.errorMessage = error.message || 'Signup failed';
    //   }
    // });
  }

  // Getter for easy access to form fields
  get f() { return this.signupForm.controls; }
}