import { AbstractControl, ValidatorFn } from '@angular/forms';

export function passwordStrengthValidator(): ValidatorFn {
  return (control: AbstractControl): {[key: string]: any} | null => {
    const value = control.value;

    // Check for minimum length
    if (value.length < 8) {
      return { 'passwordStrength': true };
    }

    // Check for at least one uppercase letter
    if (!/[A-Z]/.test(value)) {
      return { 'passwordStrength': true };
    }

    // Check for at least one lowercase letter
    if (!/[a-z]/.test(value)) {
      return { 'passwordStrength': true };
    }

    // Check for at least one number
    if (!/[0-9]/.test(value)) {
      return { 'passwordStrength': true };
    }

    // Check for at least one special character
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
      return { 'passwordStrength': true };
    }

    return null;
  };
}