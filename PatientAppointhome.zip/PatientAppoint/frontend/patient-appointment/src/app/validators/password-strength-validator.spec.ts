import { PasswordStrengthValidator } from './password-strength-validator';

describe('PasswordStrengthValidator', () => {
  it('should create an instance', () => {
    expect(new PasswordStrengthValidator()).toBeTruthy();
  });
});
