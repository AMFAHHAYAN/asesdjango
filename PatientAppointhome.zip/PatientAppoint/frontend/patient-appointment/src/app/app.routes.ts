import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
// import { ProfileComponent } from './profile/profile.component';
// import { DoctorListComponent } from './doctors/doctor-list/doctor-list.component';
// import { AppointmentScheduleComponent } from './appointments/appointment-schedule/appointment-schedule.component';
// import { AuthGuard } from './guards/auth.guard';
// import { DashboardComponent } from './dashboard/dashboard.component';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
//   { 
//     path: 'dashboard', 
//     component: DashboardComponent, 
//     canActivate: [AuthGuard] 
//   },
//   { 
//     path: 'profile', 
//     component: ProfileComponent, 
//     canActivate: [AuthGuard] 
//   },
//   { 
//     path: 'doctors', 
//     component: DoctorListComponent, 
//     canActivate: [AuthGuard] 
//   },
//   { 
//     path: 'schedule-appointment', 
//     component: AppointmentScheduleComponent, 
//     canActivate: [AuthGuard] 
//   },
//   { path: '**', redirectTo: '/login' }
];