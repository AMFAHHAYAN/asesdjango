from rest_framework.views import APIView
from rest_framework.response import Response
from .serializer import ProductSerializer
from .models import Products
# Create your views here.

class GetProduct(APIView):
    def get(self,request):
        try:   
            products = Products.objects.all()
            serializer = ProductSerializer(products,many =True)
            return Response(serializer.data)
        except:
            context = {'error':'no data found'}
            return Response(context)
        
    def post(self,request):
        try:
            data = request.data
            tittle = data.get('tittle')
            desc = data.get('desc')
            price = data.get('price')
            image = data.get('img')
            print(data)
            Products.objects.create(tittle=tittle,description = desc,price =price,image =image)
            context ={ 'msg': 'Product saved succesfully'}
            return Response (context)
        except:
            context = {'error':'something went wrong'}
            return Response(context)