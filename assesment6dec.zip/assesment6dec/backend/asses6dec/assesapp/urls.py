from .views import *
from django.urls import path

urlpatterns = [
    path('products/',GetProduct.as_view(),name = 'getproducts')
]