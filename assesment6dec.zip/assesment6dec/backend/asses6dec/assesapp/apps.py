from django.apps import AppConfig


class AssesappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'assesapp'
