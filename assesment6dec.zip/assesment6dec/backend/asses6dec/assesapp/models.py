from django.db import models

# Create your models here.
class Products(models.Model):
    tittle = models.CharField(max_length=50)
    description = models.CharField(max_length= 100)
    price = models.DecimalField(max_digits=10,decimal_places=2)
    image = models.FileField(upload_to='img/')
    