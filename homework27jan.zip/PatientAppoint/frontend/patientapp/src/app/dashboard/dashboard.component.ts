import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

interface Doctor {
  id?: number;
  name: string;
  specialization: string;
  image: string;
  location?: string;
  availability?:  { [key: string]: string }; // Assuming availability data format
  availabilityString?: string;
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  doctors: Doctor[] = [];
  loading: boolean = true;
  error: string | null = null;

  private baseUrl = 'http://127.0.0.1:8000';  // Assuming your API is hosted here

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    this.getDoctors();
  }

  // Fetch doctors from the backend
  getDoctors(): void {
    this.authService.getDoctors().subscribe(
      (data) => {
        console.log('Doctors data:', data);  // Log the received data
        this.doctors = data.map((doctor: any) => ({
          ...doctor,
          image: this.getImagePath(doctor.image),
          availabilityString: this.convertAvailabilityToString(doctor.availability)
        }));
        console.log(this.doctors);
        this.loading = false;
      },
      (error) => {
        this.error = 'Failed to load doctor data';
        this.loading = false;
        console.error(error);
  
        Swal.fire({
          title: 'Error!',
          text: 'Could not fetch doctor data',
          icon: 'error',
        });
      }
    );
  }
  

  // Convert the availability array into a readable string
  convertAvailabilityToString(availability?: { [key: string]: string }): string {
    if (!availability || Object.keys(availability).length === 0) {
      return 'Not Available';
    }

    // Convert the availability object to a readable string
    return Object.keys(availability)
      .map(day => `${day.charAt(0).toUpperCase() + day.slice(1)}: ${availability[day]}`)
      .join(', ');
  }

  // Navigate to the appointment page with doctor ID
  appointDoctor(doctor: Doctor): void {
    const doctorId = doctor.id;
    const userId = this.authService.getUserId();  // Get user ID from localStorage

    if (!userId) {
      Swal.fire({
        title: 'Error!',
        text: 'You need to be logged in to book an appointment.',
        icon: 'error',
      });
      return;
    }

    if (!doctorId) {
      Swal.fire({
        title: 'Error!',
        text: 'Doctor ID is missing.',
        icon: 'error',
      });
      return;
    }

    console.log('User ID:', userId);
    console.log('Doctor ID:', doctorId);

    // Navigate to the appointment page with both user ID and doctor ID
    this.router.navigate([`/appointments/create/${userId}/${doctorId}`]);
  }

  // Construct the full URL for doctor image
  getImagePath(path: string): string {
    if (path.startsWith('http://') || path.startsWith('https://')) {
      return path;
    }
    return `${this.baseUrl}${path.startsWith('/') ? path : '/' + path}`;
  }
}
