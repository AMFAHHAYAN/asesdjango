import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private registerUrl = 'http://127.0.0.1:8000/register/';  // URL to the backend API for registration
  private loginUrl = 'http://127.0.0.1:8000/login/';      // URL to the backend API for login
  private dashboardUrl = 'http://127.0.0.1:8000/doctor-list/';
  private logoutUrl = 'http://127.0.0.1:8000/logout/';
  private appointmentUrl = 'http://127.0.0.1:8000/appointments/';
  private appointmentDetailUrl = 'http://127.0.0.1:8000/appointments/';
  private doctordetailView = 'http://127.0.0.1:8000/doctor/';
  private myappointmentsUrl = 'http://127.0.0.1/myappointments/';  // API to fetch my appointments

  constructor(private http: HttpClient) {}

  // Method to register a user
  registerUser(userData: any): Observable<any> {
    return this.http.post<any>(this.registerUrl, userData).pipe(
      catchError(this.handleError)
    );
  }

  // Method to log in a user
  loginUser(credentials: any): Observable<any> {
    return this.http.post<any>(this.loginUrl, credentials).pipe(
      catchError(this.handleError)
    );
  }

  // Method to handle HTTP errors
  private handleError(error: any): Observable<never> {
    console.error('An error occurred:', error);
    throw error;
  }

  // Save tokens to localStorage
  saveTokens(accessToken: string, refreshToken: string): void {
    localStorage.setItem('access_token', accessToken);
    localStorage.setItem('refresh_token', refreshToken);
  }

  saveUsername(username: string): void {
    localStorage.setItem('user_name', username);
  }

  saveUserId(userId: number): void {
    localStorage.setItem('user_id', userId.toString());  // Store user ID as a string
  }

  // Get the access token from localStorage
  getAccessToken(): string | null {
    return localStorage.getItem('access_token');
  }

  // Get the refresh token from localStorage
  getRefreshToken(): string | null {
    return localStorage.getItem('refresh_token');
  }

  getUsername(): string | null {
    return localStorage.getItem('user_name');
  }

  getUserId(): number | null {
    const userId = localStorage.getItem('user_id');
    return userId ? parseInt(userId) : null;
  }

  // Remove tokens from localStorage
  removeTokens(): void {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    localStorage.removeItem('user_name');
  }

  logout(): Observable<any> {
    const refreshToken = this.getRefreshToken();

    if (!refreshToken) {
      return throwError(() => new Error('No refresh token found'));
    }

    const body = { refresh_token: refreshToken };

    return this.http.post<any>(this.logoutUrl, body).pipe(
      tap(() => this.removeTokens()),
      catchError(error => {
        console.error('Logout failed:', error);
        this.removeTokens();  // Ensure tokens are removed even on error
        return throwError(() => error);
      })
    );
  }

  // Fetch doctors list
  getDoctors(): Observable<any> {
    const accessToken = this.getAccessToken();
    if (!accessToken) {
      return throwError(() => new Error('No access token found'));
    }

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${accessToken}`
    });

    return this.http.get<any>(this.dashboardUrl, { headers }).pipe(
      catchError(this.handleError)
    );
  }

  // Create an appointment
  createAppointment(appointmentData: any): Observable<any> {
    const accessToken = this.getAccessToken();
    if (!accessToken) {
      return throwError(() => new Error('No access token found'));
    }

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${accessToken}`
    });

    return this.http.post<any>(this.appointmentUrl, appointmentData, { headers }).pipe(
      catchError(this.handleError)
    );
  }

  // Get list of appointments for the authenticated user (patient or doctor)
  getAppointments(): Observable<any> {
    const accessToken = this.getAccessToken();
    if (!accessToken) {
      return throwError(() => new Error('No access token found'));
    }

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${accessToken}`
    });

    return this.http.get<any>(this.appointmentUrl, { headers }).pipe(
      catchError(this.handleError)
    );
  }

  // Get details of a single appointment
  getAppointmentDetails(appointmentId: number): Observable<any> {
    const accessToken = this.getAccessToken();
    if (!accessToken) {
      return throwError(() => new Error('No access token found'));
    }

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${accessToken}`
    });

    return this.http.get<any>(`${this.appointmentDetailUrl}/${appointmentId}`, { headers }).pipe(
      catchError(this.handleError)
    );
  }

  // Update the status of an appointment (for doctors only)
  updateAppointmentStatus(appointmentId: number, status: string): Observable<any> {
    const accessToken = this.getAccessToken();
    if (!accessToken) {
      return throwError(() => new Error('No access token found'));
    }

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${accessToken}`
    });

    const body = { status: status };

    return this.http.patch<any>(`${this.appointmentDetailUrl}/${appointmentId}`, body, { headers }).pipe(
      catchError(this.handleError)
    );
  }

  // Fetch doctor's details
  getDoctorDetails(doctorId: number): Observable<any> {
    const accessToken = this.getAccessToken();
    if (!accessToken) {
      return throwError(() => new Error('No access token found'));
    }

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${accessToken}`
    });

    const url = `${this.doctordetailView}${doctorId}/`;

    return this.http.get<any>(url, { headers }).pipe(
      catchError(this.handleError)
    );
  }

  // Fetch the authenticated user's appointments
  getMyAppointments(): Observable<any> {
    const userId = this.getUserId();
    if (!userId) {
      return throwError(() => new Error('No user ID found'));
    }

    const accessToken = this.getAccessToken();
    if (!accessToken) {
      return throwError(() => new Error('No access token found'));
    }

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${accessToken}`
    });

    return this.http.get<any>(`${this.myappointmentsUrl}`, { headers }).pipe(
      catchError(this.handleError)
    );
  }
}
