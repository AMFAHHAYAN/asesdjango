import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SignupComponent } from './signup/signup.component'; // Import the SignupComponent
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { authGuard } from './auth.guard';
import { ProfileComponent } from './profile/profile.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { MyAppointmentsComponent } from './myappointment/myappointment.component';


const routes: Routes = [
  // Define the route for the Signup page
  { path: 'signup', component: SignupComponent },
  { path: 'login', component: LoginComponent },
  { 
    path: 'dashboard', 
    component: DashboardComponent,
    canActivate: [authGuard]
  },
  { 
    path: 'profile', 
    component: ProfileComponent, 
    canActivate: [authGuard] 
  },
  {
    path: 'appointments/create/:userId/:doctorId',
    component: AppointmentComponent,
    canActivate: [authGuard]  
  },
  { path: 'myappointments', component: MyAppointmentsComponent, canActivate: [authGuard] },
  { path: '', component: LoginComponent },
  // Optionally, you can add a redirect for the default path


  // You can also add a wildcard route for a 404 page if needed

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
