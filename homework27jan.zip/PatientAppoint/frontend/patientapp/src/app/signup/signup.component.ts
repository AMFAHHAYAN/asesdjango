import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { AuthService } from '../auth.service';  // Adjust the import path as necessary
import Swal from 'sweetalert2';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signupForm!: FormGroup;
  submitted = false;
  loading = false;
  error = '';

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authService: AuthService  
  ) {}

  ngOnInit(): void {
    this.signupForm = this.formBuilder.group({
      fullname: ['', [Validators.required, Validators.maxLength(100)]],
      date_of_birth: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: [
        '',
        [
          Validators.required,
          Validators.pattern(/^\d{10}$/) // Ensures phone number is 10 digits
        ]
      ],
      password: [
        '',
        [Validators.required, Validators.minLength(6), Validators.maxLength(100)]
      ],
      address: ['', Validators.required]
    });
  }

  // Getters for form controls
  get f() {
    return this.signupForm.controls;
  }

  // Handle form submission
  onSubmit(): void {
    this.submitted = true;
    this.error = '';
    
    if (this.signupForm.invalid) {
      return;
    }
  
    this.loading = true;
  
    // Call the register method from AuthService
    this.authService.registerUser(this.signupForm.value)
      .pipe(first())  // Ensure the observable completes on the first response
      .subscribe(
        (response) => {
          Swal.fire({
            icon: 'success',
            title: 'Registration Successful!',
            text: 'You have successfully registered. Redirecting...',
            timer: 3000,  // Optional: auto-dismiss the alert after 3 seconds
            didClose: () => {
              // Navigate to the '/success' page after the SweetAlert closes
              this.router.navigate(['/login']);
            }
          });
        },
        (error) => {
          console.error('Registration error:', error);
          this.loading = false;
  
          // Check if the error response contains validation errors
          if (error.status === 400 && error.error) {
            // Collect all validation messages into a single string
            let validationMessages = '';
  
            // Handle error response where each error is a simple string (not an array)
            for (const [field, message] of Object.entries(error.error)) {
              validationMessages += `${message}\n`;  // Field and its error message
            }
  
            // Display the validation messages as a SweetAlert message
            Swal.fire({
              icon: 'error',
              title: 'Invalid Data',
              text: validationMessages.trim(),
            });
          } else {
            // Generic error message if it's not a validation error
            Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'An error occurred during registration. Please try again later.',
            });
          }
        }
      );
  }

  gotoLogin(){
    this.router.navigate(['/login']);
  }
}
