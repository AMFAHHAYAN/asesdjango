import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  private updateProfileUrl = 'http://127.0.0.1:8000/update/';
  private userProfileUrl  = 'http://127.0.0.1:8000/profile/';

  constructor(private http: HttpClient) {}

  // Update profile method
  updateProfile(profileData: any): Observable<any> {
    const userId = localStorage.getItem('user_id');  // Assuming you store user ID in localStorage
    return this.http.patch(`${this.updateProfileUrl}${userId}/`, profileData);
  }

  getUserProfile(): Observable<any> {
    const userId = localStorage.getItem('user_id');
    return this.http.get(`${this.userProfileUrl}${userId}/`);
  }

}
