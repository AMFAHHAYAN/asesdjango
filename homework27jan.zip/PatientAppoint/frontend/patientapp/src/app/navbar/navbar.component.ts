import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit  {
  // Dynamic username - this could be retrieved from a user service or authentication service
  username: string = '';
  
  constructor(
    private authService: AuthService,
    private router: Router 
  ) {}
  ngOnInit(): void {
    // Set the dynamic username when the component is initialized
    this.username = this.authService.getUsername() || 'Guest';
  }
  logout(): void {
    this.authService.logout().subscribe(
      (response) => {
        // Clear tokens from localStorage
        this.authService.removeTokens();
        
        // SweetAlert to show success message and redirect after a few seconds
        Swal.fire({
          icon: 'success',
          title: 'Logout Successful!',
          text: 'You have successfully logged out. Redirecting...',
          timer: 3000,  // Optional: auto-dismiss the alert after 3 seconds
          didClose: () => {
            // Navigate to the login page after SweetAlert closes
            this.router.navigate(['/login']);
          }
        });
      },
      (error) => {
        console.error('Logout failed', error);
        // Optionally show an error alert to the user
        Swal.fire({
          icon: 'error',
          title: 'Logout Failed',
          text: 'There was an error while logging out. Please try again.'
        });
      }
    );
  }

  viewAppointments() {
   // Navigate to appointments page
    this.router.navigate(['/myappointments']);
  }
  profile() {
    // Navigate to profile page
    this.router.navigate(['/profile']);
  }
  
}
