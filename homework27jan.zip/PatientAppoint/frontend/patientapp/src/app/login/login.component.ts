import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { first } from 'rxjs/operators';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  submitted = false;
  loading = false;
  error = '';

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authService: AuthService  
  ) {}

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  // Getters for form controls
  get f() {
    return this.loginForm.controls;
  }

  // Handle form submission
  onSubmit(): void {
    this.submitted = true;
    this.error = '';
    
    if (this.loginForm.invalid) {
      return;
    }
  
    this.loading = true;
  
    // Call the login method from AuthService
    this.authService.loginUser(this.loginForm.value)
      .pipe(first())  // Ensure the observable completes on the first response
      .subscribe(
        (response) => {
          const accessToken = response.access;
          const refreshToken = response.refresh;
          const username = response.user_name;
          const userId = response.user_id;

          // Save both the access token and refresh token in localStorage
          this.authService.saveTokens(accessToken, refreshToken);
          this.authService.saveUsername(username);
          this.authService.saveUserId(userId);
          Swal.fire({
            icon: 'success',
            title: 'Login Successful!',
            text: 'You are successfully logged in. Redirecting...',
            timer: 3000,  // Optional: auto-dismiss the alert after 3 seconds
            didClose: () => {
              // Navigate to the '/dashboard' page after SweetAlert closes
              this.router.navigate(['/dashboard']);
            }
          });
        },
        (error) => {
          console.error('Login error:', error);
          this.loading = false;

          // Handle error response
          if (error.status === 400 && error.error) {
            let errorMessage = '';

            // Collect error messages from the backend response
            for (const [key, message] of Object.entries(error.error)) {
              errorMessage += `${message}\n`;  // Concatenate messages into a string
            }

            // Show the error messages in a SweetAlert message
            Swal.fire({
              icon: 'error',
              title: 'Invalid Credentials',
              text: errorMessage.trim(),
            });
          } else {
            // Show generic error if the response is unexpected
            Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'An error occurred during login. Please try again later.',
            });
          }
        }
      );
  }
  goToSignUp() {
    this.router.navigate(['/signup']);
  }
}
