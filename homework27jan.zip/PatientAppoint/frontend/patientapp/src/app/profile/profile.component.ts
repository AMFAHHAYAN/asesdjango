import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProfileService } from '../services/profile.service';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  profileForm: FormGroup;

  isLoading: boolean = false;
  updateSuccess: boolean = false;
  updateError: string = '';

  constructor(private fb: FormBuilder, private profileService: ProfileService) {
    // Initialize with an empty form to avoid the TypeScript error
    this.profileForm = this.fb.group({
      fullname: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required]],
      address: ['', [Validators.required]]
    });
  }

  ngOnInit() {
    // Fetch user profile data to populate form
    this.profileService.getUserProfile().subscribe(
      (profileData) => {
        this.profileForm.patchValue({
          fullname: profileData.fullname,
          email: profileData.email,
          phone: profileData.phone || '',
          address: profileData.address || ''
        });
      },
      (error) => {
        console.error('Error fetching profile data', error);
      }
    );
  }

  onSubmit() {
    if (this.profileForm.valid) {
      this.isLoading = true;
      this.profileService.updateProfile(this.profileForm.value).subscribe(
        (response) => {
          this.updateSuccess = true;
          this.isLoading = false;
          console.log('Profile updated successfully', response);
        },
        (error) => {
          this.updateError = 'There was an error updating your profile.';
          this.isLoading = false;
          console.error('Error updating profile', error);
        }
      );
    }
  }
}
