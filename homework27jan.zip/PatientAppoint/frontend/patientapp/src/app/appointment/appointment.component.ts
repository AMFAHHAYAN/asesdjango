import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../auth.service';
import Swal from 'sweetalert2';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';  // <-- Import FormBuilder, FormGroup, and Validators

@Component({
  selector: 'app-appointment-create',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css'],
})
export class AppointmentComponent implements OnInit {
  userId: number | null = null;
  doctorId: number | null = null;
  doctor: any = {};  // Object to hold doctor details
  appointmentForm!: FormGroup;  // <-- Define the form group

  // Default doctor details for fallback
  doctorImage: string = 'path/to/default/doctor-image.jpg';
  doctorName: string = 'Dr. John Doe';
  doctorSpecialization: string = 'Cardiologist';
  doctorLocation: string = '123 Medical St, City';
  doctorAvailability: string = 'Mon-Fri: 9am - 5pm';

  constructor(
    private route: ActivatedRoute,
    private authService: AuthService,
    private router: Router,
    private fb: FormBuilder  // <-- Inject FormBuilder
  ) {}
  private baseUrl = 'http://127.0.0.1:8000';

  ngOnInit(): void {
    // Initialize the form group with controls and validators
    this.appointmentForm = this.fb.group({
      date: ['', Validators.required],
      time: ['', Validators.required],
    });

    // Get the user ID and doctor ID from the route parameters
    this.route.params.subscribe(params => {
      this.doctorId = +params['doctorId'];  // Convert to number

      if ( !this.doctorId) {
        Swal.fire({
          title: 'Error!',
          text: 'User or Doctor ID is missing.',
          icon: 'error',
        });
        this.router.navigate(['/']);  // Navigate back to dashboard or home if IDs are missing
      } else {
        // Fetch doctor details if both IDs are present
        this.getDoctorDetails(this.doctorId);
      }
    });
  }

  // Fetch doctor details by doctorId
  getDoctorDetails(doctorId: number): void {
    this.authService.getDoctorDetails(doctorId).subscribe(
      (data) => {
        // Update doctor details if data is received
        this.doctor = data;
        this.doctorImage = this.getImagePath(this.doctor.image);
        this.doctorName = this.doctor.name;
        this.doctorSpecialization = this.doctor.specialization;
        this.doctorLocation = this.doctor.location || 'Not Available';
        this.doctorAvailability = this.convertAvailabilityToString(this.doctor.availability);
      },
      (error) => {
        console.error(error);
        Swal.fire({
          title: 'Error!',
          text: 'Could not fetch doctor details.',
          icon: 'error',
        });
      }
    );
  }

  // Convert the availability array into a readable string
  convertAvailabilityToString(availability?: { [key: string]: string }): string {
    if (!availability || Object.keys(availability).length === 0) {
      return 'Not Available';
    }

    return Object.keys(availability)
      .map(day => `${day.charAt(0).toUpperCase() + day.slice(1)}: ${availability[day]}`)
      .join(', ');
  }

  // Handle appointment creation
  createAppointment(): void {
    if (this.appointmentForm.invalid) {
      Swal.fire({
        title: 'Error!',
        text: 'Please fill out the form correctly.',
        icon: 'error',
      });
      return;
    }
  
    // Retrieve userId and doctorId from localStorage
    const storedUserId = localStorage.getItem('user_id');
    const patientId = storedUserId;  // Assuming user_id corresponds to the patient
  
    if (!patientId) {
      Swal.fire({
        title: 'Error!',
        text: 'User not found in localStorage.',
        icon: 'error',
      });
      return;
    }
  
    // Prepare appointment data to send to API
    const appointmentData = {
      doctor: this.doctorId, // Pass doctorId as an integer
      patient: parseInt(patientId, 10), // Pass patientId as an integer
      date: this.appointmentForm.value.date,
      time: this.appointmentForm.value.time,
      notes: '',  // Optionally include notes
    };
  
    // Call the API to create the appointment
    this.authService.createAppointment(appointmentData).subscribe(
      (response) => {
        Swal.fire({
          title: 'Success!',
          text: 'Your appointment has been created successfully.',
          icon: 'success',
        });
        this.router.navigate(['/myappointments']); // Redirect to the appointments page
      },
      (error) => {
        Swal.fire({
          title: 'Error!',
          text: 'There was an error creating the appointment.',
          icon: 'error',
        });
      }
    );
  }
  
  
  
  
  // Construct the full URL for doctor image
  getImagePath(path: string): string {
    if (path.startsWith('http://') || path.startsWith('https://')) {
      return path;
    }
    return `${this.baseUrl}${path.startsWith('/') ? path : '/' + path}`;
  }
}
