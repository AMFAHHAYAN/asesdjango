import { Component, OnInit } from '@angular/core';

import Swal from 'sweetalert2'; // For notifications if required
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-myappointment',
  templateUrl: './myappointment.component.html',
  styleUrls: ['./myappointment.component.css']
})
export class MyAppointmentsComponent implements OnInit {
  appointments: any[] = []; // Store the list of appointments
  isLoading: boolean = true; // Flag to show a loading spinner while fetching data

  constructor(private authService: AuthService) {} // Inject AuthService instead of AppointmentService

  ngOnInit(): void {
    this.fetchMyAppointments(); // Fetch appointments when the component initializes
  }

  // Method to fetch appointments for the logged-in user
  fetchMyAppointments(): void {
    this.authService.getMyAppointments().subscribe(
      (response: any) => {
        this.appointments = response.appointments; // Set the appointments from the API response
        this.isLoading = false; // Hide loading spinner
      },
      (error) => {
        Swal.fire({
          title: 'Error!',
          text: 'There was an error fetching your appointments.',
          icon: 'error',
        });
        this.isLoading = false; // Hide loading spinner
      }
    );
  }
}
