import base64
from cryptography.fernet import Fernet, InvalidToken
from django.conf import settings
from rest_framework import serializers
from django.contrib.auth.hashers import make_password, check_password
from .models import *
from urllib.parse import urljoin

class EncryptionMixin:
    @staticmethod
    def generate_key():
        return Fernet.generate_key()

    @classmethod
    def encrypt_field(cls, value):
        if not hasattr(settings, 'ENCRYPTION_KEY'):
            raise ValueError("Encryption key not set in settings")
        
        f = Fernet(settings.ENCRYPTION_KEY)
        return f.encrypt(str(value).encode()).decode()

    @classmethod
    def decrypt_field(cls, encrypted_value):
        if not hasattr(settings, 'ENCRYPTION_KEY'):
            raise ValueError("Encryption key not set in settings")
        
        f = Fernet(settings.ENCRYPTION_KEY)
        try:
            decrypted_value = f.decrypt(encrypted_value.encode()).decode()
            return decrypted_value
        except Exception as e:
            raise ValueError(f"Decryption failed: {e}")
class UserSerializer(serializers.ModelSerializer, EncryptionMixin):
    class Meta:
        model = User
        fields = ('fullname', 'email', 'date_of_birth', 'phone', 'address')

    def to_representation(self, instance):
        ret = super().to_representation(instance)
        # Decrypt sensitive fields on GET request (when returning data)
        sensitive_fields = ['phone', 'address']
        for field in sensitive_fields:
            if ret.get(field):
                ret[field] = self.decrypt_field(ret[field])
        return ret

    def update(self, instance, validated_data):
        # Encrypt sensitive fields when updating data (PATCH request)
        sensitive_fields = ['phone', 'address']
        for field in sensitive_fields:
            if field in validated_data:
                validated_data[field] = self.encrypt_field(validated_data[field])

        return super().update(instance, validated_data)

class RegisterSerializer(serializers.ModelSerializer, EncryptionMixin):
    password = serializers.CharField(write_only=True)
    
    class Meta:
        model = User
        fields = '__all__'
        
    def create(self, validated_data):
        # Check if email already exists
        email = validated_data.get('email')
        if User.objects.filter(email=email).exists():
            raise serializers.ValidationError({"email": "This email is already registered."})
        
        # Encrypt sensitive fields
        sensitive_fields = ['phone', 'address']
        for field in sensitive_fields:
            if field in validated_data:
                validated_data[field] = self.encrypt_field(validated_data[field])
        
        # Hash password
        password = validated_data.pop('password')
        validated_data['password'] = make_password(password)
        
        return super().create(validated_data)
    
    def update(self, instance, validated_data):
        # Encrypt sensitive fields
        sensitive_fields = ['phone', 'address']
        for field in sensitive_fields:
            if field in validated_data:
                validated_data[field] = self.encrypt_field(validated_data[field])
        
        # Handle password update
        password = validated_data.get('password', None)
        if password:
            validated_data['password'] = make_password(password)
        
        return super().update(instance, validated_data)

class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(max_length=100, write_only=True)

    def validate(self, data):
        from django.utils import timezone
        
        email = data.get('email')
        password = data.get('password')

        try:
            user = User.objects.get(email=email)
            
            # Check password
            if not check_password(password, user.password):
                raise serializers.ValidationError("Invalid credentials")
            
            # Update last login timestamp
            user.last_login = timezone.now()
            user.save()
            
            return data
        except User.DoesNotExist:
            raise serializers.ValidationError("User not found")

class DoctorSerializer(serializers.ModelSerializer, EncryptionMixin):
    password = serializers.CharField(write_only=True)
    email = serializers.EmailField()

    class Meta:
        model = Doctor
        fields = '__all__'

    def create(self, validated_data):
        # The password will be hashed automatically in the model's save method
        return super().create(validated_data)

    def update(self, instance, validated_data):
        # Encrypt the email or password if necessary
        sensitive_fields = ['email', 'password']
        for field in sensitive_fields:
            if field in validated_data:
                validated_data[field] = self.encrypt_field(validated_data[field])

        return super().update(instance, validated_data)

class UDoctorSerializer(serializers.ModelSerializer):
    image = serializers.SerializerMethodField()


    class Meta:
        model = Doctor
        fields = ['id', 'name', 'specialization', 'location', 'availability', 'email', 'image']

    def get_image(self, obj):
        # Construct the full URL for the image using MEDIA_URL
        return urljoin(settings.MEDIA_URL, str(obj.image)) if obj.image else None


class DoctorLoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(max_length=100, write_only=True)

    def validate(self, data):
        email = data.get('email')
        password = data.get('password')

        try:
            doctor = Doctor.objects.get(email=email)
            
            # Check password
            if not check_password(password, doctor.password):
                raise serializers.ValidationError("Invalid credentials")
            
            # Update last login timestamp (assuming you have a `last_login` field or use another mechanism)
            # doctor.last_login = timezone.now()
            # doctor.save()
            
            return data
        except Doctor.DoesNotExist:
            raise serializers.ValidationError("Doctor not found")

# Appointment serializer remains the same
class AppointmentSerializer(serializers.ModelSerializer):
    patient = RegisterSerializer(read_only=True)  
    doctor = DoctorSerializer(read_only=True)  

    class Meta:
        model = Appointment
        fields = ['id', 'patient', 'doctor', 'date', 'time', 'notes', 'status']

    def to_representation(self, instance):
        ret = super().to_representation(instance)
        
        # Ensure status is shown as a readable string
        status_map = {
            'Pending': 'Pending',
            'Confirmed': 'Confirmed',
            'Approved': 'Approved',
            'Rejected': 'Rejected',
        }
        ret['status'] = status_map.get(ret['status'], ret['status'])
        
        return ret

    def validate(self, data):
        """
        Custom validation for appointment creation: Ensure that the user is allowed to create an appointment.
        """
        user = self.context.get('request').user
        if user.is_doctor:
            raise serializers.ValidationError("Doctors cannot create appointments.")
        return data
   
    def update(self, instance, validated_data):
        """
        Ensure only the doctor can change the status of the appointment to 'Approved' or 'Rejected'.
        """
        user = self.context.get('request').user
        if user.is_doctor:
            status = validated_data.get('status', None)
            if status not in ['Approved', 'Rejected']:
                raise serializers.ValidationError("Doctor can only update status to Approved or Rejected.")
            instance.status = status
            instance.save()
        return instance
 
class UAppointmentSerializer(serializers.ModelSerializer):
    # Expect integer for patient and doctor as IDs
    patient = serializers.PrimaryKeyRelatedField(queryset=User.objects.all())  # Use PrimaryKeyRelatedField
    doctor = serializers.PrimaryKeyRelatedField(queryset=Doctor.objects.all())  # Use PrimaryKeyRelatedField

    class Meta:
        model = Appointment
        fields = ['id', 'patient', 'doctor', 'date', 'time', 'notes', 'status']

    def to_representation(self, instance):
        """
        Customize the representation of the instance for readable output.
        """
        ret = super().to_representation(instance)

        # You can customize the status representation if needed
        status_map = {
            'Pending': 'Pending',
            'Confirmed': 'Confirmed',
            'Approved': 'Approved',
            'Rejected': 'Rejected',
        }
        ret['status'] = status_map.get(ret['status'], ret['status'])

        # Ensure that patient and doctor are returned as IDs
        ret['patient'] = instance.patient.id  # Patient's ID, not the User object
        ret['doctor'] = instance.doctor.id    # Doctor's ID, not the Doctor object

        return ret

    def create(self, validated_data):
        # Extract patient and doctor from validated data (these will be User and Doctor objects)
        patient = validated_data.get('patient')
        doctor = validated_data.get('doctor')

        # Create and return the Appointment instance
        appointment = Appointment.objects.create(
            patient=patient,
            doctor=doctor,
            date=validated_data.get('date'),
            time=validated_data.get('time'),
            notes=validated_data.get('notes', ''),
        )
        return appointment
    
f = Fernet(settings.ENCRYPTION_KEY)

class AppointmentSerializer(serializers.ModelSerializer):
    def decrypt_field(self, encrypted_value):
        try:
            decrypted_value = f.decrypt(encrypted_value.encode()).decode()
            return decrypted_value
        except InvalidToken as e:
            print(f"Decryption failed for value: {encrypted_value}, Error: {str(e)}")
            raise ValueError(f"Decryption failed: {e}")

    class Meta:
        model = Appointment
        fields = '__all__'