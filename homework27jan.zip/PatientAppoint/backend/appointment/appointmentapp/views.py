from rest_framework import generics, status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.exceptions import TokenError
from django.utils import timezone
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.filters import SearchFilter
from .permissions import *
from .models import User, Doctor, Appointment
from .serializers import *

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer
    permission_classes = [AllowAny]

    def perform_create(self, serializer):
        # Additional validation or pre-create logic can be added here
        user = serializer.save()
        
        # Optional: Additional post-registration actions
        return user

class LoginView(generics.GenericAPIView):
    serializer_class = LoginSerializer
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        
        if serializer.is_valid():
            email = serializer.validated_data.get('email')
            
            try:
                user = User.objects.get(email=email)  # This will raise an exception if no user is found
            except User.DoesNotExist:
                return Response({
                    'detail': 'User not found'
                }, status=status.HTTP_404_NOT_FOUND)  # Return a 404 if user is not found

            # Check password (assuming you are comparing the plain text password)
            if not check_password(serializer.validated_data['password'], user.password):
                return Response({
                    'detail': 'Invalid credentials'
                }, status=status.HTTP_401_UNAUTHORIZED)
            
            # Generate JWT tokens
            refresh = RefreshToken.for_user(user)
            refresh['email'] = user.email
            
            # Optional: Track login attempts
            user.last_login = timezone.now()
            user.save()
            
            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
                'user_id': user.id,
                'email': user.email,
                'user_name': user.fullname
            }, status=status.HTTP_200_OK)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LogoutView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]

    def post(self, request):
        try:
            # Get refresh token from request body
            refresh_token = request.data.get('refresh_token')

            if not refresh_token:
                return Response({
                    'detail': 'Refresh token is required.'
                }, status=status.HTTP_400_BAD_REQUEST)

            # Attempt to blacklist the refresh token
            try:
                token = RefreshToken(refresh_token)
                token.blacklist()
            except TokenError:
                return Response({
                    'detail': 'Invalid refresh token.'
                }, status=status.HTTP_400_BAD_REQUEST)

            return Response({
                'detail': 'Successfully logged out.'
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'detail': f'Logout failed: {str(e)}'
            }, status=status.HTTP_400_BAD_REQUEST)

class UserRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]
    lookup_field = 'pk'

    def get_queryset(self):
        # Ensure user can only access their own record
        return User.objects.filter(id=self.request.user.id)

    def perform_update(self, serializer):
        # Additional validation or logging can be added
        serializer.save()

    def perform_destroy(self, instance):
        # Soft delete (deactivating the user instead of removing from DB)
        instance.is_active = False
        instance.save()

    def get(self, request, *args, **kwargs):

        user = self.get_object()  # This will automatically filter based on `self.request.user.id`
        serializer = self.get_serializer(user)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def patch(self, request, *args, **kwargs):

        user = self.get_object()  # Fetch the user
        data = request.data

        # Ensure that sensitive fields are encrypted before update
        sensitive_fields = ['phone', 'address']
        for field in sensitive_fields:
            if field in data:
                data[field] = UserSerializer.encrypt_field(data[field])

        # Proceed with updating the user instance
        serializer = self.get_serializer(user, data=data, partial=True)
        if serializer.is_valid():
            self.perform_update(serializer)
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    # for user (patient)
class DoctorListView(generics.ListAPIView):
    queryset = Doctor.objects.all()
    serializer_class = UDoctorSerializer
    authentication_classes = [JWTAuthentication]  # Ensure this is added
    permission_classes = [IsAuthenticated]  # Ensure this is added
    filter_backends = (SearchFilter,)
    search_fields = ['specialization']
    # Enable pagination, use the default pagination defined in settings.py
    pagination_class = None  
    
    #  for (admin panel )
class DoctorListCreateView(generics.ListCreateAPIView):
    queryset = Doctor.objects.all()
    serializer_class = DoctorSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]  
    
class DoctorDetailView(APIView):
    authentication_classes = [JWTAuthentication]  # Ensure this is added
    permission_classes = [IsAuthenticated]
    def get(self, request, pk, format=None):
        try:
            doctor = Doctor.objects.get(id=pk)
        except Doctor.DoesNotExist:
            return Response({"error": "Doctor not found"}, status=status.HTTP_404_NOT_FOUND)
        
        serializer = UDoctorSerializer(doctor)
        return Response(serializer.data)

class DoctorLoginView(generics.GenericAPIView):
    serializer_class = DoctorLoginSerializer
    permission_classes = [AllowAny]
    
    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        
        if serializer.is_valid():
            return Response({"message": "Login successful"}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class DoctorRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Doctor.objects.all()
    serializer_class = DoctorSerializer
    permission_classes = [IsAuthenticated]

import logging

logger = logging.getLogger(__name__)

class AppointmentListCreateView(generics.ListCreateAPIView):
    serializer_class = AppointmentSerializer
    permission_classes = [IsAuthenticated, IsPatientOrAdmin ]
    authentication_classes = [JWTAuthentication]

    def get_queryset(self):
        # Restrict appointments based on user type
        data = self.request.GET.get('data')
        print("Data from GET request:", data) 
        user = self.request.user
        if hasattr(user, 'is_doctor') and user.is_doctor:
            return Appointment.objects.filter(doctor=user)
        return Appointment.objects.filter(patient=user)
    
    def perform_create(self, serializer):
        logger.debug(f"Request data: {self.request.data}")
        user = self.request.user
        if not user.is_authenticated:
            raise PermissionDenied("You must be logged in to create an appointment.")

        if hasattr(user, 'is_doctor') and user.is_doctor:
            raise PermissionDenied("Doctors cannot create appointments.")

        serializer.save(patient=user)

class AppointmentRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = AppointmentSerializer
    permission_classes = [IsAuthenticated, IsDoctor, CanUpdateAppointmentStatus]

    def get_queryset(self):
        # Restrict appointment access based on user type
        user = self.request.user
        if hasattr(user, 'is_doctor') and user.is_doctor:
            return Appointment.objects.filter(doctor=user)
        return Appointment.objects.filter(patient=user)
    

class UAppointmentCreateView(APIView):
    """
    Create an appointment.
    """

    def post(self, request):
        # Assuming the request contains the doctorId and patientId (userId) along with other data
        serializer = UAppointmentSerializer(data=request.data)

        if serializer.is_valid():
            # Create the appointment
            serializer.save()

            # Return success response
            return Response({
                "message": "Appointment created successfully",
                "appointment": serializer.data
            }, status=status.HTTP_201_CREATED)

        # If the serializer is invalid, return an error response
        return Response({
            "message": "Failed to create appointment",
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)
    
class MyAppointmentsView(APIView):
    permission_classes = [IsAuthenticated]  # Ensure user is authenticated
    
    def get(self, request):
        user = request.user  # Get the authenticated user
        appointments = Appointment.objects.filter(user=user)  # Fetch appointments for this user
        serializer = AppointmentSerializer(appointments, many=True)
        return Response({"appointments": serializer.data})