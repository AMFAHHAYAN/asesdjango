from django.urls import path
from .views import *

urlpatterns = [
    # User routes
    path('register/',RegisterView.as_view(), name='register'),
    path('login/',LoginView.as_view(), name='login'),
    path('logout/',LogoutView.as_view(), name='logout'),
    path('update/<int:pk>/', UserRetrieveUpdateDestroyView.as_view(), name='user-update'),
    path('profile/<int:pk>/', UserRetrieveUpdateDestroyView.as_view(), name='user-profile'),
    
    # Doctor routes
    path('doctors/', DoctorListCreateView.as_view(), name='doctor-list-create'),
    path('doctor/<int:pk>/', DoctorDetailView.as_view(), name='doctor-detail'),
    path('doctor/login/', DoctorLoginView.as_view(), name='doctor-login'),
    path('doctors/<int:pk>/', DoctorRetrieveUpdateDestroyView.as_view(), name='doctor-retrieve-update-destroy'),
    path('doctor-list/', DoctorListView.as_view(), name='doctor-list'),
    
    # Appointment routes
    path('appointments/', UAppointmentCreateView.as_view(), name='appointment-list-create'),
    path('myappointments/', MyAppointmentsView.as_view(), name='my_appointments'),

    path('appointments/<int:pk>/', AppointmentRetrieveUpdateDestroyView.as_view(), name='appointment-retrieve-update-destroy'),
]
