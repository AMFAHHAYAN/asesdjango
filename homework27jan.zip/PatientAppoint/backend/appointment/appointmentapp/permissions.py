from rest_framework import permissions
from rest_framework.exceptions import PermissionDenied
from .models import Doctor


class IsPatientOrAdmin(permissions.BasePermission):
    """
    Custom permission to only allow patients and admins to create appointments.
    Doctors cannot create appointments.
    """

    def has_permission(self, request, view):
        user = request.user

        # Check if user is authenticated
        if not user.is_authenticated:
            return False

        # Allow admin and patient to create appointments
        if user.is_superuser or hasattr(user, 'is_patient'):
            return True
        
        # If doctor, deny access
        if hasattr(user, 'is_doctor') and user.is_doctor:
            raise PermissionDenied("Doctors cannot create appointments.")
        
        return False


class IsDoctor(permissions.BasePermission):
    """
    Custom permission to only allow doctors to perform actions on their own appointments.
    Doctors can only change the status of appointments assigned to them.
    """

    def has_permission(self, request, view):
        user = request.user
        
        # Allow doctors to view and update appointments
        if hasattr(user, 'is_doctor') and user.is_doctor:
            return True
        
        return False

    def has_object_permission(self, request, view, obj):
        """
        Allows a doctor to only update appointments assigned to them.
        """
        # Allow doctor to update only appointments that belong to them
        if hasattr(request.user, 'is_doctor') and request.user.is_doctor:
            if obj.doctor == request.user.doctor:
                return True
            return False
        
        return False


class CanUpdateAppointmentStatus(permissions.BasePermission):
    """
    Custom permission to allow only doctors to update the status of the appointment.
    The status can only be updated to 'Confirmed' or 'Rejected'.
    """

    def has_permission(self, request, view):
        # Allow only doctors to update the status
        return hasattr(request.user, 'is_doctor') and request.user.is_doctor

    def has_object_permission(self, request, view, obj):
        # Ensure the doctor can only modify appointments assigned to them
        if obj.doctor == request.user.doctor:
            # Only allow doctors to update status
            if request.method in ['PATCH', 'PUT']:
                status = request.data.get('status')
                if status not in ['Confirmed', 'Rejected']:
                    raise PermissionDenied("Doctor can only approve or reject the appointment.")
                return True
        return False
