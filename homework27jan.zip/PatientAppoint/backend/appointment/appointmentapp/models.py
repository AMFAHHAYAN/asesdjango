from django.db import models
from django.conf import settings
from django.core.mail import send_mail
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin
from django.contrib.auth.base_user import BaseUserManager

class UserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('Email is required')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        return self.create_user(email, password, **extra_fields)

# Add these fields to the User model for distinguishing between patient and doctor
class User(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(unique=True)
    fullname = models.CharField(max_length=100)
    date_of_birth = models.DateField(null=True)
    phone = models.CharField(max_length=10)
    address = models.TextField()
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    date_joined = models.DateTimeField(auto_now_add=True)

    # New fields to distinguish patient and doctor
    is_patient = models.BooleanField(default=True)  # Default is patient
    is_doctor = models.BooleanField(default=False)

    objects = UserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['fullname']

    def __str__(self):
        return self.email


    
class Doctor(models.Model):
    image = models.ImageField(upload_to='images/')
    name = models.CharField(max_length=100)
    specialization = models.CharField(max_length=50)
    location = models.TextField()
    availability = models.JSONField()
    email = models.EmailField()
    password = models.CharField(max_length=100) 
    
    def save(self, *args, **kwargs):
        if not self.pk: # Sends emails before password hashing
            send_doctor_credentials_email(self)
        
        self.password = make_password(self.password) # hash pass after sending mail
        super().save(*args, **kwargs)


def send_doctor_credentials_email(doctor):
    subject = 'HEY DOC Your credentials'
    message = f'Hey Doc, this is your login credentials for the Doctor Panel:\n\n' \
              f'URL: http://127.0.0.1:8000/doctor/login\n' \
              f'Email: {doctor.email}\n' \
              f'Password: {doctor.password}\n' \
              f'Please login and change your password after the first login.'
    from_email = settings.EMAIL_HOST_USER
    send_mail(subject, message, from_email, [doctor.email])
    
class Appointment(models.Model):
    patient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='appointments')
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    date = models.DateField()
    time = models.TimeField()
    notes = models.TextField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=[
        ('Pending', 'Pending'),
        ('Confirmed', 'Confirmed'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected')
    ], default='Pending')

    def __str__(self):
        return f"Appointment for {self.patient.fullname} with Dr. {self.doctor.name} on {self.date}"
