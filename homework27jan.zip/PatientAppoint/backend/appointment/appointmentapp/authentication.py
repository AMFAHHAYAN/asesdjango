from django.contrib.auth.backends import BaseBackend
from appointmentapp.models import User  # Import your custom User model

class EmailBackend(BaseBackend):
    def authenticate(self, request, username=None, password=None, **kwargs):
        try:
            # Use email as the username to look up the custom User model
            user = User.objects.get(email=username)  # Using your custom model
            if user.check_password(password):  # Check the password
                return user
        except User.DoesNotExist:
            return None

    def get_user(self, user_id):
        try:
            return User.objects.get(pk=user_id)  # Fetch the user by primary key (ID)
        except User.DoesNotExist:
            return None
